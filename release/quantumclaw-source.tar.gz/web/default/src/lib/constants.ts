/**
 * Application-wide constants for QuantumClaw.
 */

export const DEFAULT_SYSTEM_NAME = 'QuantumClaw'
export const DEFAULT_LOGO = '/logo.png'

export const STORAGE_KEYS = {
  SYSTEM_NAME: 'system_name',
  LOGO: 'logo',
  FOOTER_HTML: 'footer_html',
} as const
